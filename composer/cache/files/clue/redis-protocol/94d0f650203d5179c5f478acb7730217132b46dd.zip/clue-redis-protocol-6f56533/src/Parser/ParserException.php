<?php

namespace Clue\Redis\Protocol\Parser;

use UnexpectedValueException;

class ParserException extends UnexpectedValueException
{

}
