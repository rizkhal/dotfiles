<?php

use Rizkhal\Inertable\Tests\TestCase;

uses(TestCase::class)->in(__DIR__);
