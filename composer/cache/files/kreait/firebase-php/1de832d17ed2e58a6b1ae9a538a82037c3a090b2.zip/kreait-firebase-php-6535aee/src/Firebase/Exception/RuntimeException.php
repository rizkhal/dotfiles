<?php

declare(strict_types=1);

namespace Kreait\Firebase\Exception;

class RuntimeException extends \RuntimeException implements FirebaseException
{
}
