<?php declare(strict_types=1);

namespace Amp\Parallel\Context;

class StatusError extends \Error
{
}
