<?php declare(strict_types=1);

namespace Amp\Socket;

use Amp\ByteStream\StreamException;

class SocketException extends StreamException
{
}
