<?php declare(strict_types=1);

namespace Amp\Socket;

enum InternetAddressVersion
{
    case IPv4;
    case IPv6;
}
