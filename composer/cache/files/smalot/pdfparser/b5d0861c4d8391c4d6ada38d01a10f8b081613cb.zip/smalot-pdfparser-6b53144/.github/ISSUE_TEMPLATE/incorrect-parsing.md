---
name: Incorrect parsing
about: Use this template if a PDF is not parsed as expected
title: ''
labels: ''
assignees: ''

---

<!-- DO NOT THROW THIS AWAY -->
<!-- Fill out the FULL versions with patch versions -->

 - PHP Version: 
 - PDFParser Version: 

### Description:

### PDF input
<!-- If possible, please provide the PDF you are trying to parse -->

### Expected output & actual output
<!-- Share a piece of the output and the corresponding piece of input that you expected the parser would output -->

### Code
<!-- Add the code you used to parse the PDF -->
