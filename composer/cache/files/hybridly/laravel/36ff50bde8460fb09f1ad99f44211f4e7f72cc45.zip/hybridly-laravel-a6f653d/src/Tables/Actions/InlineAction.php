<?php

namespace Hybridly\Tables\Actions;

use Hybridly\Tables\Actions\Concerns\ResolvesModel;

class InlineAction extends BaseAction
{
    use ResolvesModel;
}
