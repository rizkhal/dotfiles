<?php

namespace Hybridly\Support;

/**
 * Represents a property that will automatically get evaluated in a subsequent partial reload after the view has loaded.
 */
class Deferred extends Partial
{
}
