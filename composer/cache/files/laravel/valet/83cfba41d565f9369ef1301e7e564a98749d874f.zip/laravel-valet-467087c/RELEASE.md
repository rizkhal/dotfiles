# Release Instructions

1. Update the `$version` variable in [`app.php`](./cli/app.php) and commit it
2. [Create a new GitHub release](https://github.com/laravel/valet/releases/new) for this version with the release notes
