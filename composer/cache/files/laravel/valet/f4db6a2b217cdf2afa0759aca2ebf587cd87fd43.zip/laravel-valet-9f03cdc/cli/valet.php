#!/usr/bin/env php
<?php

require_once __DIR__.'/app.php';

/**
 * Run the application.
 */
$app->run();
