# Release Notes for 11.x

## [Unreleased](https://github.com/laravel/framework/compare/v11.0.0..11.x)

## [v11.0.0 (2024-??-??)](https://github.com/laravel/framework/compare/v11.0.0...11.x)

Check the upgrade guide in the [Official Laravel Upgrade Documentation](https://laravel.com/docs/11.x/upgrade). Also you can see some release notes in the [Official Laravel Release Documentation](https://laravel.com/docs/11.x/releases).
