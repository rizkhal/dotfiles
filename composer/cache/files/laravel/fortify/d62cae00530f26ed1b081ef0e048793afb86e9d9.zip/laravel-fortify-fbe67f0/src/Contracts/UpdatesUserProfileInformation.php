<?php

namespace Laravel\Fortify\Contracts;

/**
 * @method void update(\Illuminate\Foundation\Auth\User $user, array $input)
 */
interface UpdatesUserProfileInformation
{
    //
}
