<?php

namespace Laravel\Fortify\Contracts;

/**
 * @method void reset(\Illuminate\Foundation\Auth\User $user, array $input)
 */
interface ResetsUserPasswords
{
    //
}
