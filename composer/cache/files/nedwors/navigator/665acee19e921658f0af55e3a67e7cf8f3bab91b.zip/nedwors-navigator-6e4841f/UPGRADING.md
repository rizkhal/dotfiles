# Upgrade Guide

## 0.3.0
- Navigator no longer uses `LazyCollections`, instead it uses the core `Collection` class. As such, ensure all references are updated as applicable. As such, PHP generator support has been removed.
