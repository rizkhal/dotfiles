# CHANGELOG

## Unreleased

## [1.4.0] - 2023-11-30

* Restored support for PHP 8.1

## [1.3.0] - 2023-11-25

* Added support for PHP 8.3, dropped support for PHP 8.1

## [1.2.1] - 2022-12-19

Fixed symlinks not being properly resolved

## [1.2.0] - 2022-12-01

Added more checks when decoding JSON Files

## [1.1.0] - 2022-11-04

Dropped support for PHP <8.1

## [1.0.0] - 2022-02-12

Initial release

[Unreleased]: https://github.com/beste/json/compare/1.4.0...main
[1.4.0]: https://github.com/beste/json/compare/1.3.0...1.4.0
[1.3.0]: https://github.com/beste/json/compare/1.2.1...1.3.0
[1.2.1]: https://github.com/beste/json/compare/1.2.0...1.2.1
[1.2.0]: https://github.com/beste/json/compare/1.1.0...1.2.0
[1.1.0]: https://github.com/beste/json/compare/1.0.0...1.1.0
[1.0.0]: https://github.com/beste/json/releases/tag/1.0.0
