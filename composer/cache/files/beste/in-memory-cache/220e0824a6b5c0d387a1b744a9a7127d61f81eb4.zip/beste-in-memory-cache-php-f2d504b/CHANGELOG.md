# CHANGELOG

## [Unreleased]

## [1.1.0] - 2024-03-02

* The Cache can now be instantiated without providing a [PSR-20](https://www.php-fig.org/psr/psr-20/) clock implementation.
* The library doesn't depend on the [`beste/clock` library](https://github.com/beste/clock) anymore.

## [1.0.0] - 2023-12-09

Initial Release

[Unreleased]: https://github.com/beste/in-memory-cache-php/compare/1.1.0...main
[1.1.0]: https://github.com/beste/in-memory-cache-php/compare/1.0.0...1.1.0
[1.0.0]: https://github.com/beste/in-memory-cache-php/tree/1.0.0
