<?php

declare(strict_types=1);

namespace Beste;

use Psr\Clock\ClockInterface;

interface Clock extends ClockInterface
{

}
