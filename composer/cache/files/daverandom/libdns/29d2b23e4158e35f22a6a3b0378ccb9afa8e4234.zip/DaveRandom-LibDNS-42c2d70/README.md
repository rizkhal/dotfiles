LibDNS
======

DNS protocol implementation in pure PHP
