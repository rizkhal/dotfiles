<?php

namespace Spatie\LaravelData\Contracts;

interface BaseDataCollectable
{
    public function getDataClass(): string;
}
