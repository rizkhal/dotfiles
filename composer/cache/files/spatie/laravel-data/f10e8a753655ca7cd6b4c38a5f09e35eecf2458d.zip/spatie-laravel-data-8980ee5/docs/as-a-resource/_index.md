---
title: As a resource

weight: 4
---
