---
title: As a DTO
weight: 2
---
