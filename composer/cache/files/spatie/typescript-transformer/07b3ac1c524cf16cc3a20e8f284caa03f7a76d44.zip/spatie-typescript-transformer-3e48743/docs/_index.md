---
title: v2
slogan: Convert PHP types to TypeScript
githubUrl: https://github.com/spatie/typescript-transformer
branch: main
---
