<?php

namespace Spatie\TypeScriptTransformer\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_PROPERTY)]
class Hidden
{
}
