---
title: Installation
weight: 3
---

## Basic installation

You can install this package via composer:

```bash
composer require spatie/typescript-transformer
```

We also created a Laravel specific package, you can find the installation instructions: [here](https://docs.spatie.be/typescript-transformer/v2/laravel/installation-and-setup/).
