---
title: Transforming PHP classes
weight: 3
---
