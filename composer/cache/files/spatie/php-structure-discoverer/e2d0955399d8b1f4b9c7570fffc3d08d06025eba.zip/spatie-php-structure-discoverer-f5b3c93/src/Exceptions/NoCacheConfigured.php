<?php

namespace Spatie\StructureDiscoverer\Exceptions;

use Exception;

class NoCacheConfigured extends Exception
{
}
