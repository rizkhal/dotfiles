<?php

namespace Spatie\StructureDiscoverer\Enums;

enum DiscoveredEnumType
{
    case Unit;
    case String;
    case Int;
}
