<?php

namespace Knp\Snappy\Exception;

use InvalidArgumentException;

class FileAlreadyExistsException extends InvalidArgumentException
{
}
