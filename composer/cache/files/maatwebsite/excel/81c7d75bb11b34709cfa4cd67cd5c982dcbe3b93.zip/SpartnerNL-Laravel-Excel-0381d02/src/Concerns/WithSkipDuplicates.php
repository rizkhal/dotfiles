<?php

namespace Maatwebsite\Excel\Concerns;

interface WithSkipDuplicates
{
}
